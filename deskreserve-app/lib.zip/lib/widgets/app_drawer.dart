import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../screens/login_screen.dart';
import '../screens/today_summary_screen.dart';
import '../screens/booking_history_screen.dart';
import '../screens/admin_analytics_screen.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          // Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 40, 16, 20),
            color: const Color(0xFF4A6CF7),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "DeskReserve",
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Book. Study. Focus.",
                  style: GoogleFonts.poppins(
                    color: Colors.white70,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),

          // Menu Items
          _drawerItem(
            icon: Icons.chair_alt_outlined,
            text: "Seat Booking",
            onTap: () {
              Navigator.pop(context);
            },
          ),

          _drawerItem(
            icon: Icons.schedule_outlined,
            text: "My Bookings",
            onTap: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("My Bookings – coming soon")),
              );
            },
          ),

          _drawerItem(
            icon: Icons.history,
            text: "Booking History",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const BookingHistoryScreen()),
              );
            },
          ),

          _drawerItem(
            icon: Icons.person_outline,
            text: "Profile",
            onTap: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Profile – coming soon")),
              );
            },
          ),

          _drawerItem(
            icon: Icons.today_outlined,
            text: "Today's Summary",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TodaySummaryScreen()),
              );
            },
          ),

          _drawerItem(
            icon: Icons.analytics_outlined,
            text: "Analytics",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AdminAnalyticsScreen()),
              );
            },
          ),

          const Spacer(),

          const Divider(),

          // Logout
          _drawerItem(
            icon: Icons.logout,
            text: "Logout",
            isLogout: true,
            onTap: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => LoginScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _drawerItem({
    required IconData icon,
    required String text,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return ListTile(
      leading: Icon(icon, color: isLogout ? Colors.red : Colors.grey[700]),
      title: Text(
        text,
        style: GoogleFonts.poppins(
          color: isLogout ? Colors.red : Colors.black87,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: onTap,
    );
  }
}

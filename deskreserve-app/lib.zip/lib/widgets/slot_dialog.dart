import 'package:flutter/material.dart';
import '../services/booking_service.dart';

class SlotDialog extends StatefulWidget {
  final int seatNumber;
  final List existingBookings;

  const SlotDialog({
    super.key,
    required this.seatNumber,
    required this.existingBookings,
  });

  @override
  State<SlotDialog> createState() => _SlotDialogState();
}

class _SlotDialogState extends State<SlotDialog> {
  String? selectedSlot;

  final slots = [
    "6:00 AM – 9:00 AM",
    "9:00 AM – 12:00 PM",
    "12:00 PM – 3:00 PM",
    "3:00 PM – 6:00 PM",
  ];

  bool isSlotBooked(String slot) {
    return widget.existingBookings.any((b) => b["slot"] == slot);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Seat ${widget.seatNumber}"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: slots.map((slot) {
          final booked = isSlotBooked(slot);

          return ListTile(
            title: Text(slot),
            trailing: booked
                ? const Text("Booked", style: TextStyle(color: Colors.red))
                : Radio<String>(
                    value: slot,
                    groupValue: selectedSlot,
                    onChanged: (val) {
                      setState(() {
                        selectedSlot = val;
                      });
                    },
                  ),
          );
        }).toList(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text("Cancel"),
        ),
        ElevatedButton(
          onPressed: selectedSlot == null
              ? null
              : () async {
                  await BookingService.bookSeat(
                    seatNumber: widget.seatNumber,
                    slot: selectedSlot!,
                    date: DateTime.now().toString().split(" ")[0],
                  );
                  Navigator.pop(context);
                },
          child: const Text("Confirm"),
        ),
      ],
    );
  }
}

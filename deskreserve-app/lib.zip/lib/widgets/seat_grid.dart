import 'package:flutter/material.dart';
import '../services/booking_service.dart';
import 'slot_dialog.dart';

class SeatGrid extends StatefulWidget {
  const SeatGrid({super.key});

  @override
  State<SeatGrid> createState() => _SeatGridState();
}

class _SeatGridState extends State<SeatGrid> {
  bool isLoading = true;

  List seatStatus = [];

  @override
  void initState() {
    super.initState();
    loadData(); // 🔴 REQUIRED
  }

  Future<void> loadData() async {
    try {
      final today = DateTime.now().toIso8601String().split(
        "T",
      )[0]; // YYYY-MM-DD

      seatStatus = await BookingService.getSeatStatus(date: today);
    } catch (e) {
      debugPrint("SeatGrid error: $e");
    }

    setState(() {
      isLoading = false;
    });
  }

  /// Returns list of BOOKED slots for a seat
  List<String> getSeatBookings(int seatNumber) {
    final seat = seatStatus.firstWhere(
      (s) => s["seat"] == seatNumber,
      orElse: () => null,
    );

    if (seat == null) return [];

    final slots = seat["slots"] as Map<String, dynamic>;

    return slots.entries
        .where((e) => e.value == "BOOKED")
        .map((e) => e.key)
        .toList();
  }

  /// 🔵 UI COLOR LOGIC — UNCHANGED
  Color getSeatColor(int seatNumber) {
    final count = getSeatBookings(seatNumber).length;

    if (count == 0) return Colors.green.shade500;
    if (count < 4) return Colors.orange.shade400;
    return Colors.red.shade400;
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return SafeArea(
      child: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 75, // ✅ EXACTLY 75 SEATS
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 5,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1,
        ),
        itemBuilder: (context, index) {
          final seatNumber = index + 1;
          final seatBookings = getSeatBookings(seatNumber);
          final isFullyBooked = seatBookings.length == 4;

          return GestureDetector(
            onTap: isFullyBooked
                ? null
                : () async {
                    await showDialog(
                      context: context,
                      builder: (_) => SlotDialog(
                        seatNumber: seatNumber,
                        existingBookings: seatBookings,
                      ),
                    );
                    loadData(); // 🔄 refresh after booking
                  },
            child: Container(
              decoration: BoxDecoration(
                color: getSeatColor(seatNumber),
                borderRadius: BorderRadius.circular(14),
              ),
              alignment: Alignment.center,
              child: Text(
                "S$seatNumber",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

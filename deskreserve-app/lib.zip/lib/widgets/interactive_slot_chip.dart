import 'package:flutter/material.dart';

class InteractiveSlotChip extends StatelessWidget {
  final String slotName;
  final bool isBooked;
  final VoidCallback onTap;

  const InteractiveSlotChip({
    super.key,
    required this.slotName,
    required this.isBooked,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: Chip(
        label: Text(
          slotName.toUpperCase(),
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: isBooked ? Colors.red : Colors.green,
      ),
    );
  }
}

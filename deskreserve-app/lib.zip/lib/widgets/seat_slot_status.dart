import 'package:flutter/material.dart';
import 'interactive_slot_chip.dart';

class SeatSlotStatus extends StatelessWidget {
  final int seatNumber;
  final Map<String, bool> slots;
  final Function(String slot) onSlotTap;
  final Function(String slot) onSlotLongPress;

  const SeatSlotStatus({
    super.key,
    required this.seatNumber,
    required this.slots,
    required this.onSlotTap,
    required this.onSlotLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Seat $seatNumber",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: slots.entries.map((entry) {
                return GestureDetector(
                  onTap: () => onSlotTap(entry.key),
                  onLongPress: () => onSlotLongPress(entry.key),
                  child: InteractiveSlotChip(
                    slotName: entry.key,
                    isBooked: entry.value,
                    onTap: () {}, // handled by GestureDetector
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}

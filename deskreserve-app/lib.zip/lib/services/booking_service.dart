import 'api_client.dart';

class BookingService {
  static Future<List> getSeats() async {
    return await ApiClient.get("/seats");
  }

  static Future<List> getTodayBookings() async {
    return await ApiClient.get("/bookings/today");
  }

  static Future<List> getSeatStatus({required String date}) async {
    return await ApiClient.get("/seats/status?date=$date");
  }

  static Future<bool> bookSeat({
    required int seatNumber,
    required String slot,
    required String date,
  }) async {
    final res = await ApiClient.post("/bookings", {
      "seatNumber": seatNumber,
      "slot": slot,
      "date": date,
    });
    return res["success"] == true;
  }

  static Future<List> getUserBookings() async {
    return await ApiClient.get("/bookings/user");
  }

  static Future<Map> getTodaySummary() async {
    return await ApiClient.get("/bookings/today/summary");
  }
}

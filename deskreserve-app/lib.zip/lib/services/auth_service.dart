import 'package:shared_preferences/shared_preferences.dart';
import 'api_client.dart';

class AuthService {
  static Future<bool> login(String email, String password) async {
    final res = await ApiClient.post('/auth/login', {
      "email": email,
      "password": password,
    });

    if (res["token"] != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString("token", res["token"]);
      await prefs.setString("role", res["role"] ?? "user");
      return true;
    }
    return false;
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  // ✅ CHANGE THIS IF USING REAL DEVICE
  static const String baseUrl = "http://localhost:5000/api";

  static Future<Map<String, String>> headers() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString("token");

    return {
      "Content-Type": "application/json",
      if (token != null && token.isNotEmpty) "Authorization": "Bearer $token",
    };
  }

  static Future<dynamic> get(String endpoint) async {
    final res = await http.get(
      Uri.parse("$baseUrl$endpoint"),
      headers: await headers(),
    );

    if (!res.headers.containsKey('content-type') ||
        !res.headers['content-type']!.contains('application/json')) {
      throw Exception("Server returned non-JSON response");
    }

    return jsonDecode(res.body);
  }

  static Future<dynamic> post(String endpoint, Map data) async {
    final res = await http.post(
      Uri.parse("$baseUrl$endpoint"),
      headers: await headers(),
      body: jsonEncode(data),
    );

    if (!res.headers.containsKey('content-type') ||
        !res.headers['content-type']!.contains('application/json')) {
      throw Exception("Server returned non-JSON response");
    }

    return jsonDecode(res.body);
  }
}

import 'package:flutter/material.dart';

class SlotMapper {
  /// FIXED SLOT DEFINITIONS (24-hour)
  static final slots = [
    {"name": "slot1", "start": 6, "end": 9},
    {"name": "slot2", "start": 9, "end": 12},
    {"name": "slot3", "start": 12, "end": 15},
    {"name": "slot4", "start": 15, "end": 18},
  ];

  /// RETURNS ALL SLOTS THAT OVERLAP WITH CUSTOM TIME
  static List<String> getOverlappingSlots(TimeOfDay start, TimeOfDay end) {
    final startHour = start.hour + start.minute / 60;
    final endHour = end.hour + end.minute / 60;

    return slots
        .where((slot) {
          final slotStart = slot["start"] as int;
          final slotEnd = slot["end"] as int;

          /// OVERLAP CONDITION
          return startHour < slotEnd && endHour > slotStart;
        })
        .map((s) => s["name"] as String)
        .toList();
  }
}

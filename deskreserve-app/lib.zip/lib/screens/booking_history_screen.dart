import 'package:flutter/material.dart';

class BookingHistoryScreen extends StatelessWidget {
  const BookingHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bookings = [
      {"seat": 12, "slot": "9:00 AM – 12:00 PM"},
      {"seat": 25, "slot": "12:00 PM – 3:00 PM"},
      {"seat": 41, "slot": "6:00 AM – 9:00 AM"},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Booking History")),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: bookings.length,
        itemBuilder: (context, index) {
          final booking = bookings[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: const Icon(Icons.event_seat),
              title: Text("Seat ${booking['seat']}"),
              subtitle: Text("${booking['slot']}"),
              trailing: const Icon(Icons.check_circle, color: Colors.green),
            ),
          );
        },
      ),
    );
  }
}

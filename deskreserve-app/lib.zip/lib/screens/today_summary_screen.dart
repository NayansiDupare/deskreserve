import 'package:flutter/material.dart';
import '../widgets/seat_slot_status.dart';
import '../utils/dialogs.dart';
import '../widgets/custom_registration_dialog.dart';
import '../utils/slot_mapper.dart';

/// FILTER OPTIONS
enum SeatFilter { all, booked, available }

class TodaySummaryScreen extends StatefulWidget {
  const TodaySummaryScreen({super.key});

  @override
  State<TodaySummaryScreen> createState() => _TodaySummaryScreenState();
}

class _TodaySummaryScreenState extends State<TodaySummaryScreen> {
  late List<Map<String, dynamic>> seatData;
  SeatFilter selectedFilter = SeatFilter.all;

  @override
  void initState() {
    super.initState();

    /// INITIAL MOCK DATA
    seatData = List.generate(75, (index) {
      return {
        "seat": index + 1,
        "slots": {
          "slot1": (index + 1) % 5 == 0,
          "slot2": (index + 1) % 6 == 0,
          "slot3": false,
          "slot4": (index + 1) % 9 == 0,
        },
      };
    });
  }

  /// TAP → QUICK BOOK / CANCEL
  Future<void> handleSlotTap(int seatNumber, String slot) async {
    final seatIndex = seatData.indexWhere((seat) => seat["seat"] == seatNumber);

    final slots = seatData[seatIndex]["slots"] as Map<String, bool>;

    if (slots[slot] == true) {
      final confirm = await showCancelConfirmDialog(context, seatNumber, slot);

      if (!confirm) return;

      setState(() {
        slots[slot] = false;
      });
    } else {
      setState(() {
        slots[slot] = true;
      });
    }
  }

  /// LONG PRESS → CUSTOM REGISTRATION (TIME BASED)
  Future<void> handleSlotLongPress(int seatNumber, String _) async {
    final result = await showDialog(
      context: context,
      builder: (_) => CustomRegistrationDialog(seatNumber: seatNumber),
    );

    if (result == null) return;

    final seatIndex = seatData.indexWhere((seat) => seat["seat"] == seatNumber);

    final TimeOfDay start = result["startTime"];
    final TimeOfDay end = result["endTime"];

    final affectedSlots = SlotMapper.getOverlappingSlots(start, end);

    setState(() {
      for (final slot in affectedSlots) {
        seatData[seatIndex]["slots"][slot] = true;
      }
    });

    debugPrint("CUSTOM REGISTRATION RESULT: $result");
    debugPrint("AFFECTED SLOTS: $affectedSlots");

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Seat $seatNumber booked (${affectedSlots.join(', ')})"),
      ),
    );
  }

  /// FILTER LOGIC
  List<Map<String, dynamic>> getFilteredSeats() {
    if (selectedFilter == SeatFilter.booked) {
      return seatData.where((seat) {
        return (seat["slots"] as Map<String, bool>).values.any((v) => v);
      }).toList();
    }

    if (selectedFilter == SeatFilter.available) {
      return seatData.where((seat) {
        return (seat["slots"] as Map<String, bool>).values.every((v) => !v);
      }).toList();
    }

    return seatData;
  }

  @override
  Widget build(BuildContext context) {
    final bookedCount = seatData.where((seat) {
      return (seat["slots"] as Map<String, bool>).values.any((v) => v);
    }).length;

    final availableCount = seatData.where((seat) {
      return (seat["slots"] as Map<String, bool>).values.every((v) => !v);
    }).length;

    final filteredSeats = getFilteredSeats();

    return Scaffold(
      appBar: AppBar(title: const Text("Today's Summary")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            /// SUMMARY BOXES
            Row(
              children: [
                _summaryBox("Total Seats", "75", Colors.blue),
                _summaryBox("Booked", bookedCount.toString(), Colors.red),
                _summaryBox(
                  "Available",
                  availableCount.toString(),
                  Colors.green,
                ),
              ],
            ),

            const SizedBox(height: 12),

            /// FILTER CHIPS
            Wrap(
              spacing: 10,
              children: [
                ChoiceChip(
                  label: const Text("All"),
                  selected: selectedFilter == SeatFilter.all,
                  onSelected: (_) =>
                      setState(() => selectedFilter = SeatFilter.all),
                ),
                ChoiceChip(
                  label: const Text("Booked"),
                  selected: selectedFilter == SeatFilter.booked,
                  onSelected: (_) =>
                      setState(() => selectedFilter = SeatFilter.booked),
                ),
                ChoiceChip(
                  label: const Text("Available"),
                  selected: selectedFilter == SeatFilter.available,
                  onSelected: (_) =>
                      setState(() => selectedFilter = SeatFilter.available),
                ),
              ],
            ),

            const SizedBox(height: 16),

            /// SEAT LIST
            Expanded(
              child: ListView(
                children: filteredSeats.map((seat) {
                  return SeatSlotStatus(
                    seatNumber: seat["seat"],
                    slots: seat["slots"],
                    onSlotTap: (slot) => handleSlotTap(seat["seat"], slot),
                    onSlotLongPress: (slot) =>
                        handleSlotLongPress(seat["seat"], slot),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryBox(String title, String value, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(title),
          ],
        ),
      ),
    );
  }
}

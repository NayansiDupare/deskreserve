import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/seat_grid.dart';
import '../widgets/app_drawer.dart';

class SeatScreen extends StatelessWidget {
  const SeatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const AppDrawer(), // 👈 SIDEBAR
      appBar: AppBar(
        title: Text(
          "Select Your Seat",
          style: GoogleFonts.poppins(fontWeight: FontWeight.w500),
        ),
        backgroundColor: const Color(0xFF4A6CF7),
      ),
      body: SeatGrid(),
    );
  }
}

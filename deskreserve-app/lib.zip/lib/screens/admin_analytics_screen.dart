import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AdminAnalyticsScreen extends StatefulWidget {
  const AdminAnalyticsScreen({super.key});

  @override
  State<AdminAnalyticsScreen> createState() => _AdminAnalyticsScreenState();
}

class _AdminAnalyticsScreenState extends State<AdminAnalyticsScreen> {
  int selectedRange = 0; // 0=Today, 1=Week, 2=Month

  Map<String, int> getAnalyticsData() {
    // MOCK DATA — replace with Firebase later
    if (selectedRange == 0) {
      return {
        "6:00–9:00 AM": 18,
        "9:00–12:00 PM": 42,
        "12:00–3:00 PM": 27,
        "3:00–6:00 PM": 15,
      };
    } else if (selectedRange == 1) {
      return {
        "6:00–9:00 AM": 120,
        "9:00–12:00 PM": 210,
        "12:00–3:00 PM": 165,
        "3:00–6:00 PM": 98,
      };
    } else {
      return {
        "6:00–9:00 AM": 480,
        "9:00–12:00 PM": 820,
        "12:00–3:00 PM": 610,
        "3:00–6:00 PM": 390,
      };
    }
  }

  @override
  Widget build(BuildContext context) {
    final analytics = getAnalyticsData();

    final mostUsedSlot = analytics.entries.reduce(
      (a, b) => a.value > b.value ? a : b,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text("Analytics"),
        backgroundColor: const Color(0xFF4A6CF7),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // DATE RANGE SELECTOR
            Center(
              child: ToggleButtons(
                isSelected: [
                  selectedRange == 0,
                  selectedRange == 1,
                  selectedRange == 2,
                ],
                onPressed: (index) {
                  setState(() {
                    selectedRange = index;
                  });
                },
                borderRadius: BorderRadius.circular(10),
                selectedColor: Colors.white,
                fillColor: const Color(0xFF4A6CF7),
                children: const [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text("Today"),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text("Week"),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text("Month"),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // MOST USED SLOT CARD
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Most Used Slot",
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    mostUsedSlot.key,
                    style: GoogleFonts.poppins(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                  Text(
                    "${mostUsedSlot.value} bookings",
                    style: GoogleFonts.poppins(),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // BREAKDOWN TITLE
            Text(
              "Slot Usage Breakdown",
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),

            const SizedBox(height: 12),

            // BREAKDOWN LIST
            Expanded(
              child: ListView(
                children: analytics.entries.map((entry) {
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      title: Text(entry.key),
                      trailing: Text(
                        entry.value.toString(),
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
